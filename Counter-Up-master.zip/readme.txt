https://github.com/bfintal/Counter-Up


Include

<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<script src="jquery.counterup.min.js"></script>

HTML

<span class="counter">1,234,567.00</span>
<span>$</span><span class="counter">1.99</span>
<span class="counter">12345</span>

jQuery

$('.counter').counterUp();

or with extra parameters

$('.counter').counterUp({
    delay: 10,
    time: 1000
});

delay - The delay in milliseconds per number count up

time - The total duration of the count up animation